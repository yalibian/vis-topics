// box a window to upload files used to create a visulization system, with will return a iframe window

;console.log("hello world in create_vis");


function popUpload_1() {
    console.log("pop upload div");

    $("#upload-vis-file-1").hide();


}

